using MySql.Data.MySqlClient;

namespace MyWpfApp
{
    public static class MyBDModels
    {
        // Замените 123456789 на ваш реальный пароль от MySQL
        public static string ConnectionString = "server=localhost;user=root;password=123456789;database=rcis_db_pr1;AllowPublicKeyRetrieval=True;";

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(ConnectionString);
        }
    }
}
