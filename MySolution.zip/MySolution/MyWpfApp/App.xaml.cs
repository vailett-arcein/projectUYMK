﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace MyWpfApp;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
     protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Принудительно создаем окно авторизации и показываем его
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
        }
}

