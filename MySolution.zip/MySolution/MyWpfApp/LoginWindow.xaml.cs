using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient; // Обязательно добавьте этот using

namespace MyWpfApp;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class LoginWindow : Window
{
    private List<int> _clickedSequence = new List<int>();
        private List<int> _correctSequence = new List<int> { 1, 2, 3, 4 };
        private bool _isPuzzleSolved = false;
    public LoginWindow()
    {
        
        InitializeComponent();
    }
        // Обработка кликов по капче
     private void Puzzle_Click(object sender, RoutedEventArgs e)
        {
            if (_isPuzzleSolved) return;

            Button btn = sender as Button;
            int tag = Convert.ToInt32(btn.Tag);

            _clickedSequence.Add(tag);
            btn.IsEnabled = false; // Блокируем нажатую кнопку

            // Проверка, если нажали 4 раза
            if (_clickedSequence.Count == 4)
            {
                if (_clickedSequence[0] == 1 && _clickedSequence[1] == 2 && 
                    _clickedSequence[2] == 3 && _clickedSequence[3] == 4)
                {
                    _isPuzzleSolved = true;
                    txtError.Foreground = System.Windows.Media.Brushes.Green;
                    txtError.Text = "Капча пройдена!";
                }
                else
                {
                    _clickedSequence.Clear();
                    btnPuzzle1.IsEnabled = true; btnPuzzle2.IsEnabled = true;
                    btnPuzzle3.IsEnabled = true; btnPuzzle4.IsEnabled = true;
                    txtError.Foreground = System.Windows.Media.Brushes.Red;
                    txtError.Text = "Капча собрана неверно. Попробуйте снова.";
                    // Здесь можно добавить счетчик ошибок капчи
                }
            }
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните логин и пароль!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!_isPuzzleSolved)
            {
                MessageBox.Show("Сначала соберите капчу!", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var conn = MyBDModels.GetConnection()) 
                {
                    conn.Open();
                    string query = "SELECT id, password_hash, role, is_blocked, failed_attempts FROM users WHERE login = @login";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@login", login);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                bool isBlocked = reader.GetBoolean("is_blocked");
                                if (isBlocked)
                                {
                                    MessageBox.Show("Вы заблокированы. Обратитесь к администратору", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Error);
                                    return;
                                }

                                string dbHash = reader.GetString("password_hash");
                                string role = reader.GetString("role");
                                int userId = reader.GetInt32("id");

                                // Проверка пароля (используя BCrypt)
                                if (BCrypt.Net.BCrypt.Verify(password, dbHash))
                                {
                                    // Успешный вход - сбрасываем счетчик ошибок
                                    ResetAttempts(userId);
                                    MessageBox.Show("Вы успешно авторизовались", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                                    
                                    // Открываем следующее окно в зависимости от роли
                                    if (role == "Администратор")
                                    {
                                        new AdminWindow().Show();
                                    }
                                    else
                                    {
                                        // Окно для обычного пользователя
                                        MessageBox.Show("Вы вошли как Пользователь.", "Информация");
                                    }
                                    this.Close();
                                }
                                else
                                {
                                    HandleFailedAttempt(userId);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}", "Критическая ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void HandleFailedAttempt(int userId)
        {
            using (var conn = MyBDModels.GetConnection()) 
            {
                conn.Open();
                // Увеличиваем счетчик ошибок
                string updateQuery = "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = @id";
                using (var cmd = new MySqlCommand(updateQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@id", userId);
                    cmd.ExecuteNonQuery();
                }

                // Проверяем, не превысили ли лимит
                string checkQuery = "SELECT failed_attempts FROM users WHERE id = @id";
                using (var cmd = new MySqlCommand(checkQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@id", userId);
                    int attempts = Convert.ToInt32(cmd.ExecuteScalar());

                    if (attempts >= 3)
                    {
                        string blockQuery = "UPDATE users SET is_blocked = TRUE WHERE id = @id";
                        using (var blockCmd = new MySqlCommand(blockQuery, conn))
                        {
                            blockCmd.Parameters.AddWithValue("@id", userId);
                            blockCmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("Вы заблокированы из-за 3 неверных попыток. Обратитесь к администратору", "Блокировка", MessageBoxButton.OK, MessageBoxImage.Stop);
                    }
                    else
                    {
                        MessageBox.Show($"Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные. Осталось попыток: {3 - attempts}", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void ResetAttempts(int userId)
        {
            using (var conn = MyBDModels.GetConnection()) 
            {
                conn.Open();
                string query = "UPDATE users SET failed_attempts = 0 WHERE id = @id";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", userId);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    
}