﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using trpopr1.NewFolder1;

namespace trpopr1
{
    /// <summary>
    /// Логика взаимодействия для moderator.xaml
    /// </summary>
    public partial class moderator : Window
    {
        NewFolder1.TRPO_practic1Entities1 bd;
        int CountProblem = 0;
        public moderator()
        {
            InitializeComponent();
        }
        public bool Proverka0()
        {
            var proverka = new Regex(@"((?=.*[a-z]))").Match(pascswordBX.Password);
            var PROVERKA = new Regex(@"((?=.*[A-Z]))").Match(pascswordBX.Password);
            var proverkaChislo = new Regex(@"((?=.*[0-9]))").Match(pascswordBX.Password);
            var proverkaSim = new Regex(@"((?=.*[@#$%]))").Match(pascswordBX.Password);
            string message = "";

            if (pascswordBX.Password.Length < 8)
            {
                message += "Пароль должен содержать минимум 8 символов и максимум 16 символов!\n";
            }
            else
            if (!proverka.Success)
            {
                message += "Пароль должен содержать буквы нижнего регистра\n";
            }
            else
            if (!PROVERKA.Success)
            {
                message += "Пароль должен содержать буквы верхнего регистра\n";
            }
            else
            if (!proverkaChislo.Success)
            {
                message += "Пароль должен содержать цифры\n";
            }
            else
            if (!proverkaSim.Success)
            {
                message += "Пароль должен содержать специальный сивол @#$%!\n";
            }

            if (message == "")
                return true;
            else
                MessageBox.Show(message, "Произошла ошибка при регистрации", MessageBoxButton.OK, MessageBoxImage.Stop);
            //if (TypeUs.Items == 0)
            //{

            //}
            for (int i = 0; i <= pascswordBX.Password.Length - 3; i++)
            {
                if (pascswordBX.Password[i] == pascswordBX.Password[i + 1] && pascswordBX.Password[i + 1] == pascswordBX.Password[i + 2])
                {
                    message += "В строке не должно быть более трех одинаковых символов\n";
                }
            }
            return false;

        }
        private void saveBt_Click(object sender, RoutedEventArgs e)
        {
            var rNumber = new Regex(@"[0-9]+");
            var rUpper = new Regex(@"[A-Z]+");
            var rLower = new Regex(@"[a-z]+");
            var rMinMax = new Regex(@".{6,12}");
            var rSymbols = new Regex(@"[!@#$%^&*()_+=\[{\]};:<>|./?-]");
            
            //int newID = 0;
            //UserIDBX.Text = newID.ToString();
            NewFolder1.TRPO_practic1Entities1 polsovatel = new NewFolder1.TRPO_practic1Entities1();
            if (loginBX.Text == "" | (pascswordBX.Password == "") | (nameBX.Text == ""))
            {
                MessageBox.Show("Не все поля заполнены", "Произошла ошибка при регистрации", MessageBoxButton.OK, MessageBoxImage.Stop);
                CountProblem++;
            }
            else
            {
                if (App.tRPO_Pr1Entities.moderators.Any(proverka => proverka.Login == loginBX.Text))
                {
                    MessageBox.Show("Данный пользователь уже зарегистрирован! Пройдите авторизацию", "Произошла ошибка при регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (Proverka0())
                    {
                        if (nameBX.Text != string.Empty && loginBX.Text != string.Empty
                            && (pascswordBX.Password != string.Empty))
                        {
                            NewFolder1.moderators mod = new NewFolder1.moderators
                            {
                                //moderatorID = IDcodeBX.Text,
                                //UserID = newID,


                                surname = surnameBX.Text,
                                name = nameBX.Text,
                                patronymic = patronymicBX.Text,
                                Password = pascswordBX.Password,
                                Login = loginBX.Text,
                                Role = role.Text,
                                @event = eventBX.Text,

                            };
                            bd.moderators.Add(mod);
                            bd.SaveChanges();
                            var id_user = bd.moderators.Where(x => x.Login == loginBX.Text).FirstOrDefault();
                            login login1 = new login();
                            login1.Show();
                            this.Close();

                            //NewFolder1.Users auto = new NewFolder1.Users
                            //{
                            //    Surname = surnameBox.Text,
                            //    Username = Names.Text,
                            //    Patronymic = patronymicBox.Text,
                            //    login = loginthxBox.Text,
                            //    password = passwords.Password,
                            //};
                            //polsovatel.Users.Add(auto);
                            //polsovatel.SaveChanges();
                            //login login1 = new login();
                            //login1.Show();
                            //this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Пароли не совпадают", "Произошла ошибка при регистрации", MessageBoxButton.OK, MessageBoxImage.Stop);
                        }
                        CountProblem++;
                    }
                }
            }
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            login logins = new login();
            logins.Show();
            Close();
        }
    }
}
