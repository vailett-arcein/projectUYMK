﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using trpopr1.NewFolder1;

namespace trpopr1
{
    /// <summary>
    /// Логика взаимодействия для login.xaml
    /// </summary>
    public partial class login : Window
    {
        public login()
        {
            InitializeComponent();
            PaymentBD = new NewFolder1.TRPO_practic1Entities1();
            //cbLogin.ItemsSource = PaymentBD.Users.ToList();
            var userLogins = PaymentBD.users.Select(item => item.login).ToList();//Получение логинов пользователей из БД
            
        }
        TRPO_practic1Entities1 PaymentBD;
        int Countproblems = 0;
        int clock = 10;
        DispatcherTimer timer = new DispatcherTimer();
        private void enter_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                passwordsKeyTbox.Text = passwords.Password;

                if (IdNumberTX.Text == "" | passwords.Password == "" | passwordsKeyTbox.Text == "")
                {
                    MessageBox.Show("Не все поля заполнены", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    var polsovatel = App.tRPO_Pr1Entities.users.FirstOrDefault(BDlogpass => BDlogpass.UserID == Convert.ToInt32(IdNumberTX.Text) && (BDlogpass.password == passwords.Password || BDlogpass.password == passwordsKeyTbox.Text));
                    if (polsovatel != null)
                    {
                        switch (polsovatel.UserID)
                        {
                            case 1:
                                moderator moderator0 = new moderator();
                                moderator0.Show();

                                this.Close();
                                break;
                            case 2:
                                organizer organizer0 = new organizer();
                                organizer0.Show();

                                this.Close();
                                break;
                            case 3:
                                jury jury0 = new jury();
                                jury0.Show();
                                this.Close();
                                break;
                        }
                    }
                    else
                    {
                        Countproblems++;

                        Proverka();
                    }
                }
            }
            catch
            {

            }


            string loggs = IdNumberTX.Text.Trim();
            string passwordBox = passwords.Password.Trim();

            if (loggs.Length < 8)
            {
                //logintxBox.ToolTip = "";
                IdNumberTX.ToolTip = "Логин введён некорректно!!!";
                IdNumberTX.Background = Brushes.DarkRed;

                //if (loggs.Length>16)
                //{                //}
                //else //if()
                //MessageBox.Show("Максимальная длинна пароля 16");
            }
            else if (passwordBox.Length < 5)
            {
                passwords.ToolTip = "Пароль введён некорректно!!!";
                passwords.Background = Brushes.DarkRed;
            }
            else
            {
                IdNumberTX.ToolTip = "";
                IdNumberTX.Background = Brushes.Transparent;
                passwords.ToolTip = "";
                passwords.Background = Brushes.Transparent;
                MessageBox.Show("Авторизация прошла успрешно!");
            }
        }

        int not = 10;
        public void Proverka()
        {
            if (Countproblems == 1)
            {
                MessageBox.Show("Данные введены некорректно!", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            if (Countproblems == 2)
            {
                captcha capcha = new captcha();
                capcha.ShowDialog();
            }
            if (Countproblems >= 5)
            {
                timer.Tick += new EventHandler(timertick);
                timer.Interval = new TimeSpan(0, 0, 1);
                timer.Start();
                if (clock != 0)
                {
                    this.IsEnabled = false;
                    MessageBox.Show(String.Format("Вы заблокированы на 10 секунд", clock));
                }
            }
        }
        private void timertick(object sender, EventArgs e)
        {
            if (clock == 0)
            {
                this.IsEnabled = true; ;
                MessageBox.Show("Вход в систему возобновлен, повторите попытку!");
                timer.Stop();
                clock = 10;
            }
            else
            {
                clock--;
            }

        }
        private void regis_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void offeyesName_Click(object sender, RoutedEventArgs e)
        {

        }

        private void oneyesName_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
