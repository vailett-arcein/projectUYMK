﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace trpopr1
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static readonly NewFolder1.TRPO_practic1Entities1 tRPO_Pr1Entities = new NewFolder1.TRPO_practic1Entities1();
    }
}
