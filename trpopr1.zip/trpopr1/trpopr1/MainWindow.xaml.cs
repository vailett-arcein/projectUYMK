﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using trpopr1.NewFolder1;

namespace trpopr1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
            TRPO_practic1Entities1 tRPO_Pr1Entities  = new TRPO_practic1Entities1();
        private ObservableCollection<DataRowView> data;
        public MainWindow()
        {
            InitializeComponent();
            //LoadData();   DESKTOP-GOIFFIK\SQLEXPRESS
        }
        //private void LoadData()
        //{
        //    string connectionString = "DESKTOP-GOIFFIK\\SQLEXPRESS"; // Замените на свою строку подключения

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();
        //        string query = "SELECT * FROM event"; // Замените YourTableName на имя вашей таблицы
        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
        //            {
        //                DataTable dataTable = new DataTable();
        //                adapter.Fill(dataTable);
        //                data = new ObservableCollection<DataRowView>((IEnumerable<DataRowView>)dataTable.DefaultView);
        //            }
        //        }
        //    }

        //    DG.ItemsSource = data;
        //}
        private void enter_Click_1(object sender, RoutedEventArgs e)
        {
            login login1 = new login();
            login1.Show();
            this.Close();
        }

        private void showBT_Click(object sender, RoutedEventArgs e)
        {
            DG.ItemsSource = tRPO_Pr1Entities.events.ToList();
            //OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;DataSource")
        }
    }
}