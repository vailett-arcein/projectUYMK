﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace trpopr1
{
    /// <summary>
    /// Логика взаимодействия для organizer.xaml
    /// </summary>
    public partial class organizer : Window
    {
        public organizer()
        {
            InitializeComponent();
        }

        private void event_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window1 = new MainWindow();
            window1.Show();
            this.Close();
        }

        private void juty_Click(object sender, RoutedEventArgs e)
        {
            moderator moderator1 = new moderator();
            moderator1.Show();
            this.Close();
        }

        private void usersevent_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
